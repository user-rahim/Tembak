while true

do

clear;date 

sleep 1

done

if done return